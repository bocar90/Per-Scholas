
public class Hospital {

	public static void main(String[] args) {
		Surgeon s = new Surgeon();
	    s.Doctor_Details();
	    s.Surgeon_Details();

	}
}
