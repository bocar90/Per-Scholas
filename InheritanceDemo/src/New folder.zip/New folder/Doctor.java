
class Doctor {
	String DoctorName;
	String Department;
	public void Doctor_Details() {
		System.out.println("Doctor Details..."); 
	}
}
