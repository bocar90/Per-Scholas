
public class Surgeon extends Doctor{
	void Surgeon_Details() {
		System.out.println("Surgeon  Detail...");
	    System.out.println(Department = "Cardio");
	}
}
