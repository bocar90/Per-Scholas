package com.perscholas.SP12SpringCRUDDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sp12SpringCrudDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sp12SpringCrudDemoApplication.class, args);
	}

}
